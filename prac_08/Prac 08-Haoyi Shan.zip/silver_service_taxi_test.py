from silver_service_taxi import SilverServiceTaxi

taxi = SilverServiceTaxi("Hummer", 200, 4)
print(taxi)
