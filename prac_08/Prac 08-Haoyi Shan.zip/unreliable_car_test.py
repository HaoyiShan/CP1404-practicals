from unreliable_car import UnreliableCar

car = UnreliableCar("new car", 100, 45.63)
car.drive(40)
print(car)
