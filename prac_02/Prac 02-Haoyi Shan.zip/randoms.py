import random
print(random.randint(5, 20))  # line 1 max:20 min:5
print(random.randrange(3, 10, 2))  # line 2 max:9 min:3 cannot produce 4
print(random.uniform(2.5, 5.5))  # line 3 max:5.5 min:2.5

print(random.uniform(1,100))